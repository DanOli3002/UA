Use cineteatro;


Create table Produtos (
    Codigo BigInt primary key,
    Nome Varchar(30),
    Preco BigInt
    )

Create table Pessoa (
    NIF BigInt primary key,
    Nome Varchar(30),
    Telefone Varchar(30),
    Morada Varchar(30)
    )

Create table Cliente (
    FK_NIF BigInt primary key,
    foreign key (FK_NIF) References Pessoa(NIF)
    )

Create table Funcionario (
    ID_Funcionario BigInt primary key,
    Funcao Varchar(30),
    Salario BigInt,
    FK_NIF BigInt,
    foreign key (FK_NIF) References Pessoa(NIF)
    )

Create table Edificio (
    Nome Varchar(30) primary key,
    Morada Varchar(30),
    Telefone Varchar(30)
    )

Create table Bar (
    ID_Bar BigInt primary key,
    Aberto bit,
    FK_ID_Funcionario BigInt,
    FK_NomeEdificio Varchar(30),
    foreign key (FK_ID_Funcionario) References Funcionario(ID_Funcionario),
    foreign key (FK_NomeEdificio) References Edificio(Nome)
    )

Create table Artista (
    Nome Varchar(30) primary key
    )

Create table Eventos (
    ID_Evento BigInt primary key,
    Nome Varchar(30),
    Duracao Time,
    [Data] Date,
    Tipo Varchar(30),
    FK_NomeEdificio Varchar(30),
    foreign key (FK_NomeEdificio) References Edificio(Nome)
    )

Create table Bilheteira (
    ID_Bilheteira BigInt primary key
    )

Create table Bilhete (
    Codigo BigInt primary key,
    [Data] Date,
    Lugar Varchar(30),
    FK_ID_Evento BigInt,
    FK_ID_Bilheteira BigInt,
    foreign key (FK_ID_Evento) References Eventos(ID_Evento),
    foreign key (FK_ID_Bilheteira) References Bilheteira(ID_Bilheteira)
    )

Create table Compra (
    ID_Recibo BigInt primary key,
    [Data] Date,
    MetodoPagamento Varchar(30),
    FK_CodigoProduto BigInt,
    FK_NIF_Cliente BigInt,
    FK_ID_Bar BigInt,
    foreign key (FK_CodigoProduto) References Produtos(Codigo),
    foreign key (FK_NIF_Cliente) References Cliente(FK_NIF),
    foreign key (FK_ID_Bar) References Bar(ID_Bar)
    )