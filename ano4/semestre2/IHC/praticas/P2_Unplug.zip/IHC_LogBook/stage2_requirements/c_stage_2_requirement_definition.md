[Back to main Logbook Page](../hci_logbook.md)

---

# C. Requirement Definition

>     Based on all the gathered context, including an understanding of current practices, competitors, and user feedback and expectations:
>     - summarize the user characteristics, context, and motivations using Personas
>     - explain your vision for a novel solution that will target user motivations using Scenarios
>     - identify requirements

# Personas

## Persona: João Marques

### Summary

| Attribute        | Details                                                                                            |
| ---------------- | -------------------------------------------------------------------------------------------------- |
| **Photo**        | ![Persona Name](personas/joao_marques.jpg)                                                         |
| **Name**         | João Marques                                                                                       |
| **Age**          | 19                                                                                                 |
| **Occupation**   | Estudante                                                                                          |
| **Location**     | Aveiro, Portugal                                                                                   |
| **Goals**        | Reduzir tempo no telemóvel                                                                         |
| **Pain Points**  | Falta de motivação e disciplina, pois requer iniciativa prórpia para iniciar certos blocos de foco |
| **Motivation**   | "Desinstalei o vício para voltar a instalar a minha própria vida."                                 |
| **Full Profile** | [📄 Read More](personas/persona1_template.md)                                                      |

---

## Persona: Rui Velho

### Summary

| Attribute        | Details                                                      |
| ---------------- | ------------------------------------------------------------ |
| **Photo**        | ![Persona Name](personas/rui_velho.jpg)                      |
| **Name**         | Rui Velho                                                    |
| **Age**          | 54                                                           |
| **Occupation**   | Bancario                                                     |
| **Location**     | Porto, Portugal                                              |
| **Goals**        | Desenvolver e manter novos hábitos                           |
| **Pain Points**  | Perde o entusiasmo por falta de feedback e incentivos        |
| **Motivation**   | "Os dias passam rápido demais quando fazemos sempre o mesmo" |
| **Full Profile** | [📄 Read More](personas/persona2_template.md)                |

---

# Scenarios

## Scenario 1: João Marques reduz o seu tempo no telefone

O João Marques sempre teve um vício grande com o seu telemóvel, e desde que começou a universidade esse vício se agravou pois começou até a utilizar o telemóvel durante as aulas. Foi nesse momento que ele descobriu **Unplug**, e decidiu instala-la para ver se com ela consegueria mudar o seu estilo de vida atual.

Após a instalação da app, foi lhe explicado algumas das funcionalidades principais e básicas, no sentido de criação de blocos de foco, ou seja momentos onde o telemóvel ficará bloqueado por certos momentos, sendo que estes podem ser imediatos, então irá ser criado um bloco de foco total por o tempo que foi determinado, ou de rotina, isto é, pode ser defenido um horário, por exemplo, 23:00-7:00 (horário de sono) bloquear todas as apps que levem a distrações digitais (redes socias, jogos, etc), ou 9:00-13:00 (aulas) onde bloquea outras apps, e no modo rotina ele pode selecionar o dia da semana que ele deseja que estes blocos sejam ativados.

Então o João inicialmente cria um horário de sono, com o intuito de quando se deitar não ficar acordado até as 1:00 da manhã no telefone, podendo assim ter um horário de sono melhor, e com isto ele passa o seu dia normalmente, e quando chegou a hora de ele se deitar (22:30) ele começou a ver as redes socias, até que às 23:00 ele recebe uma notificação a dizer que ele entrou no bloco de foco que defeniu e as apps que ele selecionou para serem bloqueadas são bloqueadas, sendo que caso ele tente entrar numa destas aparece no seu ecrã a informação a dizer que ele está no seu bloco de foco. Assim o João ao ver isto decide então pousar o telefone e ir dormir. Claramente se ele quisesse existe a opção de desativar o bloco de foco.

## Scenario 2: Rui Velho começar um novo hábito

O Rui Velho depois de chegar em casa após o seu trabalho, passa a maior parte do tempo no facebook, e sente que podia usar o seu tempo livre de forma mais produtiva, mas sempre que tentou no passado ele acaba por se esquecer ou desmotivar. Porém desta vez ele conheceu **Unplug** e decidiu tentar novamente com ela. Dentro da app ele foi para aba de hábitos, e selecionou que queria começar um novo hábito, neste caso ser a leitura de um livro, ele ai definiu alguns objetivos que deseja, por exemplo, ler 10 horas semanais (1,4 horas diárias), e preencheu os restantes pontos necessários.

Depois no dia seguinte (vamos considerar que é uma segunda feira) quando chega em casa ele recebe uma notificação que ainda não leu pelo menos 1h hoje, e ele com essa notificação é lembrado do objetivo que definiu, e começa a ler, depois de ler por 2 horas ele vai a app e diz que ficou a ler por aquele tempo, e com isso a app atualiza o progresso, a dizer que tem 2/10 horas feitas.

E o Rui velho por acaso consegui ler 2h todos os outros dias, então no fim dessa semana ele teve o seguinte progresso 14/10 horas feitas. Ai a app dá uma espécie de recompensa (dependedo de utilizador pode variar).

E com isto o Rui conseguiu se manter motivado para chegar até o fim do seu objetivo semanal que definiu, e com a notificação diária ele conseguiu não deixar nenhum dia sem ler.

---

# Requirements

## C.1. Functional requirements

- RF1: Criar blocos de foco imediatos - O utilizador deve conseguir iniciar um bloco de foco om duração que ele definir;
- RF2: Criar blocos de foco de rotina - O utilizador deve conseguir configurar blocos de foco de forma recorrente por dias de semana e intervalo de horário;
- RF3: Selecionar apps a bloquear por bloco - Cada bloco de foco deve permitir escolher que aplicações ficam bloqueadas;
- Rf4: Ativar bloqueio automaticamente dentro do horário definido - Quando chega a hora configurada, o sistema ativa o bloqueio sem ação manual do utilizador;
- RF5: Mostrar aviso ao tentar abrir app bloqueada - Durante o bloco, tentar abrir uma app bloqueada deve ser mostrado uma mensagem clara de bloqueio;
- Rf6: Permitir pausar/sair de bloco de foco (emergência) - O utilizador deve conseguir interromper um bloco de foco;
- RF7: Criar e gerir objetivos de hábito - O utilizador deve conseguir criar objetivos diários/semanais associados a atividades;
- RF8: Registar o progresso de hábitos - O utilizador deve poder registar tempo/quantidade realizada e ver o progresso(ex do cenário 2)
- RF9: Enviar lembrete/notificações . O sistema deve notificar quando um bloco começa e quando metas diárias ainda não foram cumpridas.

## C.2. Non-functional requirements

- RNF1: Usabilidade e simplicidade - A UI deve ser simples e clara, com foco em ações essencias;
- RNF2: Feedback imediato - Após certas ações (iniciar bloco, bloquear app, registar progresso, etc) o feedback deve ser imediato;
- RNF3: Controlo do utilizador - Deve existir a opção de cancelar ações com confirmação para evitar erros sem querer (clicar sem querer num botão);

---

[Back to main Logbook Page](hci_logbook.md)
