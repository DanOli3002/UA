# ![Persona Name](joao_marques.jpg)

**Name:** João Marques  
**Age:** 19
**Occupation:** Estudante
**Location:** Aveiro, Portugal

## Background

O João Marques é estudante de Gestão na universidade de Aveiro e encontra-se atualmente no segundo ano da licenciatura. Cresceu com um forte contacto com a tecnologia e com as redes sociais, o que o tornou bastante dependente do telemóvel no seu dia a dia.

## Daily Life

João costuma começar o dia a verificar as redes sociais logo após acordar, passando muito tempo no telemóvel antes mesmo de sair da cama. Durante as aulas, tem dificuldade em resistir à tentação de pegar no telemóvel para ver notificações ou navegar nas redes sociais.
No tempo livre, em vez de se dedicar a atividades produtivas ou a hobbies, acaba frequentemente por passar longos períodos em doomscrolling. À noite, o mesmo padrão repete-se: João fica no telemóvel até tarde, o que acaba por prejudicar o seu horário de sono e a sua energia no dia seguinte.

## Goals & Needs

O João gostaria de reduzir o tempo que passa no telemóvel e melhorar a sua capacidade de concentração, especialmente durante os períodos de estudo. Procura também tornar-se mais organizado no seu dia a dia e estabelecer uma rotina de sono mais saúdavel.

## Pain Points & Challenges

Apesar de já ter experimentado aplicações como o Forest, João sente que estas dependem demasiado da sua própria iniciativa. Como é ele que precisa de iniciar manualmente os blocos de foco, muitas vezes acaba por se distrair antes mesmo de começar. A falta de mecanismos que o incentivem ou lembrem de iniciar esses momentos de concentração torna difícil manter a consistência.

## Motivation

_"Why do they engage with this product or service?"_  
"Desinstalei o vício para voltar a instalar a minha própria vida."
