# ![Persona Name](rui_velho.jpg)

**Name:** Rui Velho  
**Age:** 54
**Occupation:** Bancario
**Location:** Porto, Portugal

## Background

O Rui Velho trabalha como bancario para o banco Montepio há mais de 30 anos. Ao longo da sua carreira desenvolveu uma rotina bastante estável e previsível. No entanto, com o passar dos anos, começou a sentir que lhe falta motivação para criar novos hábitos ou introduzir mudanças positivas no seu dia a dia. Apesar de reconhecer a importância de se manter ativo e produtivo fora do trabalho, tem dificuldade em encontrar formas consistentes de o fazer.

## Daily Life

O Rui Velho acorda cedo para se preparar para o seu dia no trabalho no banco. Durante o dia interage com os clientes ajudando-os a resolver vários problemas/dúvidas que estes possam ter.
Quando chega a casa ao final do dia, Rui tende a passar imenso tempo no Facebook. Muitas vezes pensa que poderia utilizar melhor o seu tempo livre, por exemplo para aprender algo novo, fazer exercício,etc.., mas sente dificuldade em manter-se motivado ou mesmo lembrar-se das atividades/tarefas que tem que fazer.

## Goals & Needs

Rui gostaria de desenvolver e manter hábitos mais saudáveis e produtivos no seu tempo livre. Procura formas simples de organizar melhor o seu tempo e de receber lembretes ou incentivos que o ajudem a manter a consistência. O seu objetivo é sentir que aproveita melhor o tempo fora do trabalho e melhorar a sua qualidade de vida.

## Pain Points & Challenges

Rui já tentou criar rotinas ou listas de tarefas para ocupar melhor o seu tempo, mas acaba por perder o entusiasmo ao fim de poucos dias. Muitas vezes distrai-se facilmente com o telemóvel e acaba por adiar as atividades que tinha planeado. A falta de motivação constante e de lembretes eficazes faz com que tenha dificuldade em manter novos hábitos.

## Motivation

_"Why do they engage with this product or service?"_
"Os dias passam rápido demais quando fazemos sempre o mesmo"
