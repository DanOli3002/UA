[Back to main Logbook Page](../hci_logbook.md)

---

# A. Stage 0 - Planning and Problem Identification

>     Here you will briefly explain the domain of the problem you identified, briefly identify general challenges and, then, state you problem

# Context

O contexto deste trabalho é a produtividade pessoal. A aplicação foca-se em ajudar a organizar melhor o dia, reduzir distrações digitais e manter consistência nas rotinas. Este tema é interessante porque muitas pessoas têm dificuldades em gerir tempo, tarefas e foco quando usam o telemóvel e o computador para tudo.

# Challenges

Um dos principais desafios é eliminar ou bloquear distrações digitais sem tornar a experiência demasiado rígida. Também é difícil manter uma agenda atualizada com datas e tarefas importantes, e transformar objetivos diários/semanais em hábitos reais. Outro desafio é manter a motivação ao longo do tempo, por isso a contagem de streaks pode ajudar a incentivar a continuidade.

# The goal

Criar uma app que ajude os utilizadores a manter foco e consistência, combinando blocos de concentração, agenda de tarefas/datas, objetivos periódicos e streaks motivacionais.

[Back to main Logbook Page](hci_logbook.md)
