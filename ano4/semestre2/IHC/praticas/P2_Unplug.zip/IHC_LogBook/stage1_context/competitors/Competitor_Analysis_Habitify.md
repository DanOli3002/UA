# Competitor Analysis: Habitify 
## General Information 
- **Name of System:** Habitify 
- **Company/Developer:** Unstatic Ltd.
- **Website/Product Page:** https://www.habitify.me
- **Version/Release Date:** 34.1.0 
- **Platform(s) Supported:** Mobile (iOS, Android), Web, Apple Watch 
- **Target Audience:** Qualquer pessoa 

--- 
## Core Functionality 

**Primary Purpose:** Habitify é uma aplicação de rastreio de hábitos que ajuda os utilizadores a definir, acompanhar e manter rotinas diárias, com foco em consistência e produtividade pessoal 

**Key Features:** Criação de hábitos personalizados com lembretes e notificações - Estatísticas visuais de progresso -Visualização diária/semanal/mensal dos hábitos

**Unique Selling Points (USPs):** - Sistema de streaks que incentiva consistência, e uma interface limpa e intuitiva que facilita a utilização diária 

**Limitations/Weaknesses:** - Não bloqueia outras aplicações ou distracções no dispositivo - A longo prazo torna-se pouco motivadora uma vez que não tem incentivos adicionais - Versão gratuita é muito limitada, oferecendo poucas funcionalidades.

---

## Screenshots


## Online Reviews
"Versão grátis muito limitada, só dá para colocar 3 hábitos" Lauane Goncalves,2/5 estrelas

"Poor platform, lacking easy features that could be easy to fix: Include better features for weight loss; Include better measurement units and extend the range of minutes and times; Have hour format on 24h instead of 12am/pm - I have deeply regreted paying for premium" Ettore Cavalieri, 1/5 estrelas