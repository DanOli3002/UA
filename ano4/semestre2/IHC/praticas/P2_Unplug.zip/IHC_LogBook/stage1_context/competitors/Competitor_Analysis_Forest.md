# Competitor Analysis: Forest 
## General Information 
- **Name of System:** Forest 
- **Company/Developer:** Seekrtech
- **Website/Product Page:** [\[URL\]](https://www.forestapp.cc/)
- **Version/Release Date:** 5.9.0
- **Platform(s) Supported:** Mobile
- **Target Audience:** Qualquer pessoa 

--- 
## Core Functionality 

**Primary Purpose:** Incentivar em manter o foco numa atividade e distância do telefone 

**Key Features:** - Monitorizar o tempo de foco - Diminuir a procastinação 

**Unique Selling Points (USPs):** - Transforma o tempo de foco em arvóres que podemos por numa floresta 

**Limitations/Weaknesses:** - É bastante simples, e tem problemas de otimização. Direcionado a paying users.

---

## Screenshots


## Online Reviews
"O aplicativo fica pior a cada atualização, estão basicamente tirando todas as funcionalidades da versão grátis para tentar te obrigar a assinar a versão plus." Eliane Moreira, 1/5 estrelas
"Utilizo o Forest a 4 anos, comprei a versão Pro, porque valia a pena e nunca tive problemas com o aplicativo. Mas nas últimas semanas o aplicativo apresentou muitos bug's, não calculava algumas horas de foco, travava muito e o desafio mensal às vezes não atualizava..." Sara Vital, 1/5 estrelas
