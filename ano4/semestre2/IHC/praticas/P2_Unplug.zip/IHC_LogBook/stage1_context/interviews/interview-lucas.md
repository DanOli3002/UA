# Informal User Interview Notes

>     The questions included in this file are just possibilities. The questions you do should be adapted to your case, where needed.

## Interview Details

- **Date:** 15/3/2026
- **Interviewer:** José Santos
- **Participant:** Estudante (Lucas)
- **Context:** Informal

---

## Task Overview

**Contexto geral de uso do telemóvel**

- **Quanto tempo achas que passas no telemóvel por dia?**
  - 2h por dia
- **Quais apps sentes que te ‘puxam’ mais tempo sem perceberes?**
  - Youtube e Instagram
- **Consideras o telefone algo que te distrai de outras atividades que tens por fazer?**
  - Não

**Gestão do dia e objetivos pessoais**

- **Consegues gerir bem o dia sem dificuldade?**
  - Sim
- **Consegues manter o ritmo para objetivos pessoais definidos?**
  - Sim

**Procrastinação e estratégias atuais**

- **O que fazes quando percebes que estás a procrastinar no telemóvel?**
  - Largo o telemóvel e faço o que tenho a fazer
- **Já usaste alguma app para te ajudar a focar? Qual?**
  - Não

---

## Tools & Environment

**Ferramentas e métodos atuais**

- Nenhuma

**Limitações/frustrações com essas ferramentas**

- Nunca utilizou

**Preferências de acompanhamento e funcionalidades desejadas**

- **Gostas de ver progresso (ex: streaks, estatísticas, feedback visual)?**
  - Sim
- **Quais funcionalidades gostarias que essa aplicação tivesse?**
  - Gostava que me desse objetivos baseados nas rotinas que tenho

---

## Expectations for a Novel Approach

**Como seria uma solução ideal para ti?**

- Ser de alguma forma pressionado a fazer

**Que receios/tensões tens em relação a novas apps de produtividade?**

- Perder autonomia e fazer os meus objetivos mais por obrigação

**Como medes sucesso na gestão do foco e produtividade?**

- Comparo ao meu eu anterior, e vejo a evolução perante cenários iguais

---

## Additional Observations

[Free space for any other relevant notes, behaviors, or comments]
