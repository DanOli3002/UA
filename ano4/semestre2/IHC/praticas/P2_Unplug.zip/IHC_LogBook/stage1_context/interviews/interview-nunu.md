# Informal User Interview Notes

>     The questions included in this file are just possibilities. The questions you do should be adapted to your case, where needed.

## Interview Details

- **Date:** 15/3/2026
- **Interviewer:** José Santos
- **Participant:** Estudante (Nunu)
- **Context:** Informal

---

## Task Overview

**Contexto geral de uso do telemóvel**

- **Quanto tempo achas que passas no telemóvel por dia?**
  - 7h por dia
- **Quais apps sentes que te ‘puxam’ mais tempo sem perceberes?**
  - Tiktok e Youtube
- **Consideras o telefone algo que te distrai de outras atividades que tens por fazer?**
  - Não

**Gestão do dia e objetivos pessoais**

- **Consegues gerir bem o dia sem dificuldade?**
  - Não
- **Consegues manter o ritmo para objetivos pessoais definidos?**
  - Com alguma dificuldade

**Procrastinação e estratégias atuais**

- **O que fazes quando percebes que estás a procrastinar no telemóvel?**
  - Largo o telemóvel imediatamente
- **Já usaste alguma app para te ajudar a focar? Qual?**
  - Nunca

---

## Tools & Environment

**Ferramentas e métodos atuais**

- Nenhuma

**Limitações/frustrações com essas ferramentas**

- Nunca utilizou

**Preferências de acompanhamento e funcionalidades desejadas**

- **Gostas de ver progresso (ex: streaks, estatísticas, feedback visual)?**
  - Sim
- **Quais funcionalidades gostarias que essa aplicação tivesse?**
  - Alguma forma de castigo inofensivo

---

## Expectations for a Novel Approach

**Como seria uma solução ideal para ti?**

- Insultos creativos

**Que receios/tensões tens em relação a novas apps de produtividade?**

- Não roube os dados pessoais

**Como medes sucesso na gestão do foco e produtividade?**

- Observando o progresso da tarefa em si.

---

## Additional Observations

[Free space for any other relevant notes, behaviors, or comments]
