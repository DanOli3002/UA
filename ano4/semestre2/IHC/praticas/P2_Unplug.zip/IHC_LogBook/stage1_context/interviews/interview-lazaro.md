# Informal User Interview Notes

>     The questions included in this file are just possibilities. The questions you do should be adapted to your case, where needed.

## Interview Details

- **Date:** 12/3/2026
- **Interviewer:** Daniel Oliveira
- **Participant:** Estudante (O Lazaro)
- **Context:** forma informal no aquário

---

## Task Overview

**Contexto geral de uso do telemóvel**

- **Quanto tempo achas que passas no telemóvel por dia?**
  - 6h por dia
- **Quais apps sentes que te ‘puxam’ mais tempo sem perceberes?**
  - Youtube ou Reddit
- **Consideras o telefone algo que te distrai de outras atividades que tens por fazer?**
  - Sim

**Gestão do dia e objetivos pessoais**

- **Consegues gerir bem o dia sem dificuldade?**
  - Não
- **Consegues manter o ritmo para objetivos pessoais definidos?**
  - Não

**Procrastinação e estratégias atuais**

- **O que fazes quando percebes que estás a procrastinar no telemóvel?**
  - Continuo
- **Já usaste alguma app para te ajudar a focar? Qual?**
  - As definições do telefone (Bem-estar digital dá para por bloqueio em algumas app após algumas horas)

---

## Tools & Environment

**Ferramentas e métodos atuais**

- Definições do telefone
- Pousar o telefone

**Limitações/frustrações com essas ferramentas**

- Não senti falta de nada

**Preferências de acompanhamento e funcionalidades desejadas**

- **Gostas de ver progresso (ex: streaks, estatísticas, feedback visual)?**
  - Sim
- **Quais funcionalidades gostarias que essa aplicação tivesse?**
  - Não sei

---

## Expectations for a Novel Approach

**Como seria uma solução ideal para ti?**

- O Telefone entrar em modo desligado após algumas horas de uso

**Que receios/tensões tens em relação a novas apps de produtividade?**

- Que não bloqueie nenhuma funcionalidade essencial do telemovel

**Como medes sucesso na gestão do foco e produtividade?**

- Observando o progresso da tarefa em si.

---

## Additional Observations

[Free space for any other relevant notes, behaviors, or comments]
