# Informal User Interview Notes

>     The questions included in this file are just possibilities. The questions you do should be adapted to your case, where needed.

## Interview Details

- **Date:** 13/3/2026
- **Interviewer:** Daniel Oliveira
- **Participant:** Estudante (Ricardo)
- **Context:** forma informal

---

## Task Overview

**Contexto geral de uso do telemóvel**

- **Quanto tempo achas que passas no telemóvel por dia?**
  - 3-4 horas
- **Quais apps sentes que te ‘puxam’ mais tempo sem perceberes?**
  - Instagram
- **Consideras o telefone algo que te distrai de outras atividades que tens por fazer?**
  - Sim

**Gestão do dia e objetivos pessoais**

- **Consegues gerir bem o dia sem dificuldade?**
  - Normalmente sim
- **Consegues manter o ritmo para objetivos pessoais definidos?**
  - Normalmente sim

**Procrastinação e estratégias atuais**

- **O que fazes quando percebes que estás a procrastinar no telemóvel?**
  - Pouso o telefone, e faço a tarefa em mão
- **Já usaste alguma app para te ajudar a focar? Qual?**
  - Usei aquelas restrições no Instagram onde aparacem um aviso após certas horas (que defeni) de uso

---

## Tools & Environment

**Ferramentas e métodos atuais**

- Restrições nas aplicações de uso
- Pousar o telefone

**Limitações/frustrações com essas ferramentas**

- Fico na mesma um bocado no telefone
- E com as restrições muitas vezes fico chateado e vou desliga-las

**Preferências de acompanhamento e funcionalidades desejadas**

- **Gostas de ver progresso (ex: streaks, estatísticas, feedback visual)?**
  - Sim
- **Quais funcionalidades gostarias que essa aplicação tivesse?**
  - Que me informasse os aspetos positivos em manter uma rotina numa certa tarefa/atividade

---

## Expectations for a Novel Approach

**Como seria uma solução ideal para ti?**

- Eliminar as redes sociais ou fortemente altera-las

**Que receios/tensões tens em relação a novas apps de produtividade?**

- São maior parte à base de subscrições mensais

**Como medes sucesso na gestão do foco e produtividade?**

- Observando o progresso da tarefa em si, ou aquelas que já conclui.

---

## Additional Observations

[Free space for any other relevant notes, behaviors, or comments]
