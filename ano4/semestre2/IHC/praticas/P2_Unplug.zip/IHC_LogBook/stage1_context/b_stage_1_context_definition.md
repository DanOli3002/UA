[Back to main Logbook Page](../hci_logbook.md)

---

# B. Stage 1 - Context Definition

# B.1. Competitor Identification

>     The competitor analysis will entail an identification of all competitors, with brief descriptions and a collection of the look and feel of their solutions, e.g., with screenshots, etc. It will also include a detailed analysis of the competitor deemed the best or more representative. It ends with a summary of the main findings including an HCI SWOT analysis

## B.1a. Competitors

| **Competitor** | **Description**                                                                   | Information repository                                 |
| -------------- | --------------------------------------------------------------------------------- | ------------------------------------------------------ |
| Forest         | APP para bloqueio de distrações digitais                                          | [📄 Docs](competitors/Competitor_Analysis_Forest.md)   |
| Habitify       | Aplicação de rastreio de hábitos focada em manter rotinas diárias e consistência. | [📄 Docs](competitors/Competitor_Analysis_Habitify.md) |

## B.1b. Detailed Competitor Analysis

>     Choose the most notable competitor and do a more thorough analysis of their interactive solution

### - Heuristic Evaluation

#### Method

A avaliação heurística foi realizada por 3 especialistas independentes que analisaram a interface das aplicações concorrentes. O procedimento avaliou as interfaces de acordo com heurísticas de usabilidade estabelecidas.
A severidade foi avaliada com base numa escala de 0 a 4 (considerando impacto, frequência e persistência):
0 - Não é um problema; 1 - Problema cosmético; 2 - Problema menor; 3 - Problema major; 4 - Catástrofe de usabilidade.
Após as avaliações individuais, a equipa reuniu as análises numa tabela de consenso em que discutimos e atribuímos uma severidade final a cada problema encontrado, definindo ainda as respetivas recomendações.

#### Individual Evaluations

<!-- For the individual heuristic evaluations by each member of the group, you can use the templates below, grouping problems by heuristic OR each evaluator can have a table listing all the detected problems with the number of the violated heuristics on the second column. Whichever your choice, you should have a list of problems, the severity, and a recommendation to mitigate it -->

- [expert1_heuristic_evaluation_workbook](heuristic_evaluations/expert1_heuristic_evaluation_workbook.md)

- [expert2_heuristic_evaluation_workbook](heuristic_evaluations/expert2_heuristic_evaluation_workbook.md)

- [expert3_heuristic_evaluation_workbook](heuristic_evaluations/expert3_heuristic_evaluation_workbook.md)

#### Consensus

>     After the individual analysis by each expert, all results should be gathered in a consensus table. If an expert has not found any of the problems found by other experts, they should analyse it, at this point, and give it a severity.

| **Issue**       | **Expert 1** | Expert 2 | Expert 3 | Recommendations                             |
| --------------- | ------------ | -------- | -------- | ------------------------------------------- |
| Something wrong | 3            | 1        | 0        | Something could be done to the button to... |
| Another thing   | 4            | 3        | 4        | Other thing to recommend                    |
| ...             |              |          |          |                                             |

---

### - Cognitive Walkthrough

#### Method

Usamos o Streamlined Cognitive Walkthrough, com o proposito de analisar se um utilizador consegue efetuar e compreender as tarefas que esta a executar.

#### Task Selection and Task Analysis

Selecionámos um conjunto de tarefas essenciais que um utilizador terá de dominar para conseguir utilizar e retirar real benefício da aplicação para gestão do tempo/foco. Tais como: criar, agendar e gerir blocos de foco, além de estipular objetivos macro. Estas encapsulam o "core loop" da plataforma.

| Task                         | Subtasks                                      |
| ---------------------------- | --------------------------------------------- |
| **1. Criar o bloco de foco** | Definir o tipo de bloco (imediato ou rotina): |
|                              | -Aplicações a bloquear                        |
|                              | -Definir o horário                            |
|                              | -Definir dias (rotina)                        |
|                              | -Definir nome (rotina)                        |
|                              | -pausa de urgência                            |

| Task                           | Subtasks                 |
| ------------------------------ | ------------------------ |
| **2. Gerir os blocos de foco** | mudar o nome             |
|                                | alterar a hora           |
|                                | alterar o dia            |
|                                | alterar o bloqueio       |
|                                | cancelar o bloco de foco |

| Task                  | Subtasks       |
| --------------------- | -------------- |
| **3. Marcar eventos** | dar o nome     |
|                       | marcar o dia   |
|                       | definir o tipo |
|                       | definir a hora |

| Task                      | Subtasks |
| ------------------------- | -------- |
| **4. Desmarcar o evento** |          |

| Task                        | Subtasks                                          |
| --------------------------- | ------------------------------------------------- |
| **5. Definir os objetivos** | definir o espaço temporal (diário/semanal/mensal) |
|                             | associar a um bloco de foco                       |

#### Results

Task: Criar blocos de foco
| Step # | Task/Action to Perform | Will User Know What to do at this step? (Yes/No) | Notes | If the user does the right thing, will they know it is progressing towards goal? (Yes/No) | Notes | Is Action Successful? (Yes/No) | Suggestions for Improvement | |
| ------ | ---------------------- | ------------------------------------------------ | ----- | ----------------------------------------------------------------------------------------- | ----- | ------------------------------ | --------------------------- | --- |
| 1 | definir o tipo de bloco (imediato ou rotina) | Yes | | Yes | | Yes | [Suggestion 1] | |
| 2 | (Imediato) Selecionar a duração | Yes | Vai ser algo estilo o temporizador do telefone | Yes | Vai ser possível ver em tempo real a duração que estiver a definir | Yes | [Suggestion 2] | |
| 3 | (rotina) Definir Horário (dias da semana e hora) | Yes | Vai ser possível ver os vários dias da semana para selecionar | Yes | O dia da semana selecionado será highlighted em comparação aos outros | Yes | [Suggestion 3] | |
| ... | [Further steps] | [Yes/No] | | [Yes/No] | | [Yes/No] | [Suggestions] | |

## B.1c. Overall Analysis

Através do nosso painel de concorrentes, identificámos conclusões importantes nas plataformas focadas em produtividade:

- Ferramentas como o **Habitify** e **Forest** exibem uma navegação fluída, interfaces limpas e fortes elementos visuais e de tracking;
- Muitas das funcionalidades vitais estão limitadas a uma barreira paga, o que limita consideravelmente o engagement para os utilizadores gratuitos;
- Ao longo do tempo, a app torna-se frustrante por causa dos paywalls ou dos recorrentes bugs (não contabilizar tempo ou encravar), criando o problema crónico de insatisfação do utilizador a longo prazo.

**HCI SWOT Analysis**

- **Strengths (Forças):** Elementos de gamificação robustos; bom _tracking_ visual diário/mensal e interfaces limpas e minimalistas.
- **Weaknesses (Fraquezas):** Ausência da capacidade de bloqueio rígido do telefone em algumas opções (caso Habitify) e funcionalidades gratuitas esparsas o que degrada a experiência do utilizador standard. Elevados _bugs_ de performance no Forest.
- **Opportunities (Oportunidades):** Construir uma plataforma de foco que combine o melhor: estatísticas intuitivas e um bloqueador sólido (sem distrações que não podem ser contornadas e com boa performance offline sem crashar).
- **Threats (Ameaças):** Elevada quantidade de alternativas no mercado ("App Fatigue"); que a app caia no mesmo buraco de fraca escalabilidade provocando queixas de bugs por desatualização, bem como falhas em gerir a motivação de uso a longo termo.

---

# B.2. Users

>     For the users, there are two goals: 1) understand the current status of users in the domain you are addressing. How do they manage, what are the main tasks they do, if they use some tool for the purpose, what are current challenges, what might be improved, what might be new features, ...

## B.2a. Method

A abordagem consistiu num conjunto de entrevistas informais semi-estruturadas, sendo a população alvo principalmente baseada em estudantes universitários. A escolha destas pessoas provém do facto de serem expostas continuamente ao telemóvel e requererem foco considerável nos seus afazeres letivos.
O principal objetivo incluiu mapear os atuais problemas com os _smartphones_ ao reterem a atenção, quais ferramentas são usadas presentemente para o evitar (se existirem) e explorar as soluções imaginadas pelo estudante.
As principais questões envolveram "Quanto tempo passas no telemóvel?", as aplicações mais dispendiosas de tempo (ex. Instagram/TikTok), o grau de capacidade do utilizador para manter o "deep work" e estratégias em uso.

## B.2b. Results

>     This section tracks all informal user interviews, summarizing key insights and linking to detailed notes for each session.

### Interview List

| Date       | Participant / Role | Key Insights                                                                                                                                                                          | Link to Notes                               |
| ---------- | ------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------- |
| 12-03-2026 | Lazaro / student   | Distrai-se com certas apps e dificilmente consegue manter um ritmo de trabalho.                                                                                                       | [📄 Notes](interviews/interview-lazaro.md)  |
| 13-03-2026 | Ricardo / student  | Reconhece que o telemóvel é uma distração (Instagram), mas consegue largar o dispositivo. Usa ferramentas do próprio sistema para limitar uso, apesar de não serem 100% eficazes.     | [📄 Notes](interviews/interview-ricardo.md) |
| 15-03-2026 | Lucas / student    | Passa poucas horas no telemóvel (2h). É organizado, não utiliza apps de produtividade por não sentir necessidade, conseguindo focar-se e concluir as tarefas ignorando o dispositivo. | [📄 Notes](interviews/interview-lucas.md)   |
| 15-03-2026 | Nunu / student     | Passa muito tempo no telefone (7h: TikTok e Youtube). Tem dificuldade em gerir o dia e os objetivos. Curiosamente, não considera o telemóvel um fator de distração grave.             | [📄 Notes](interviews/interview-nunu.md)    |

### Common Themes & Patterns

- **Recurring Problems:**
  - Redes Sociais e Consumo de Vídeo curtos (especialmente Instagram, TikTok e YouTube) são os maiores bloqueadores da atenção dos estudantes e onde se perde mais tempo sem intenção;
  - Dificuldade, por parte de alguns utilizadores, em manter um ritmo consistente de trabalho;
  - Utilizadores não consideram o telemóvel a principal distração, mesmo quando registam um "tempo de ecrã" bastante elevado por dia (falta de perceção).
- **Frequently Used Tools:**
  - Aplicações de sistema (_soft locks_): Restrições de tempo in-build (Aviso de "Tempo Diário" nas definições ou em aplicações como o Instagram);
  - Afastamento físico puro e direto ("pousar o telemóvel e ir fazer a tarefa em mãos"). Nenhum deles utilizou recentemente blocadores completos _third-party_.
- **Desired Features / Solutions:**
  - Ferramentas que sejam restritivas de forma autêntica mas configuráveis (alguns avisos da Apple/Instagram são facilmente contornados prolongando o bloqueio por mais minutos, por exemplo, o caso do Ricardo);
  - Mecanismos para aumentar a motivação face aos afazeres e auxiliar os indivíduos a criarem pequenos ritmos consistentes sem a dependência da dopamina instantânea;
  - Feedback visual/estatístico dos progressos sem excessivas paywalls, permitindo tornar a visualização do dia-a-dia numa gestão mais percetível de se entender.

---

[Back to main Logbook Page](../hci_logbook.md)

---
